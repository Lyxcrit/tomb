This is an add-on powered by the Splunk Add-on Builder and used in conjunction with TOMB
TOMB: https://git.badass33.com/401CPT/tomb
For assistance contact:
Brent Matlock - Lyx
brent.matlock@gosplunk.com